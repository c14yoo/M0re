from HIDS.system_file_safe import *
from HIDS.user_safe import *
# from HIDS.send_wb import *
from HIDS.peizhi_safe import *
import os,threading,time

#获取文件路径
def return_path(filename):
    cmd = f"find / -name {filename}"
    path = os.popen(cmd).readlines()
    # print(path)
    return path

#python文件挂在
def back_python(filenames):
    #获取文件对应的路径，并编写命令，挂载在后台
    path = return_path(filenames)
    pwd = path[0].replace(filenames,'').strip()
    cmd = f"cd {pwd} && python3 {filenames} &"
    print(cmd)
    os.system(cmd)
        

#计划任务写入
def Write_Crontab(new_cront):
    permion = "crontab -l"
    cron_info = os.popen(permion).readlines()
    for old in cron_info:
        old = old.strip()
        if old == new_cront:
            print("该任务已经存在!")
        else:
            cmd = f"echo {new_cront} >> /var/spool/cron/root"
            os.system(cmd)
            # os.system("/sbin/service crond reload")
            print("程序写入计划任务。")



#python创建异步后台程序编，写入函数，并且后台挂在该脚本，【定时任务】
def up_back_system(funciotn_name):
    with open("./HIDS/permiton_of_pro.py",'r') as fp1:
        funct = fp1.read()
    # print(funct)
    if funciotn_name not in funct:
        with open("./HIDS/permiton_of_pro.py",'a') as fp2:
            fp2.writelines("    "+funciotn_name+"\n")
        #删除已有的进程，查出PID
        aspux = "ps -aux | grep permiton_of_pro.py | awk '{print $2}'"
        pids = os.popen(aspux).readlines()
        if len(pids) > 1:
            for kid in pids:
                kil = f"kill {kid.strip()}"
                os.popen(kil).readlines()
        #获取文件的地址
        back_python("permiton_of_pro.py")
    else:
        print("该进程正在启动！")



#功能清单选择
def functions_home(numb):
    if numb == 1:
        system_safe()
    elif numb == 2:
        shadow_weak_pass()
    elif numb == 3:
        group_chack()
    elif numb == 4:
        user_input()
    elif numb == 5:
        print("该功能需要进行挂载，巡检时间3/s一次")
        up_back_system('MySQL_log_blast()')
    elif numb == 6:
        print("该功能需要进行挂载，巡检时间3/s一次")
        up_back_system('SSH_log_blast()')
    elif numb == 7:
        print("该功能需要进行挂载，巡检时间3/s一次")
        up_back_system('cpu_chack()')
    elif numb == 8:
        print("启动文件监控！")
        #后台挂载脚本
        back_python("ontime_chack.py")
    elif numb == 9:
        #NIDS 后台启动
        print('启动NIDS')
        cron = '* * * * * echo "0" > /opt/Comprehensive_Inspection/NIDSaccess_count.txt'
        Write_Crontab(cron)
        #后台挂载脚本
        back_python("detective1.py")

def user_choise(systemctl_list):
    print()
    print()
    print("[+][+][+]———————————————————————————————————————————————————————————————————————[+][+][+]")
    print("功能清单：")
    for show in systemctl_list:
        print(show)
    print("[+][+][+]———————————————————————————————————————————————————————————————————————[+][+][+]")
    cho = input("输入序号执行程序:") 
    for c in cho :
        try:
            c = int(c)
            if c == 1 or c == 2 or c == 3 or c == 4:
                functions_home(c)
            elif (c == 5 or c == 6 or c == 7 or c == 8 or c == 9) and  ("进程已启动！" not in systemctl_list[c-1]):
                functions_home(c)
                systemctl_list[c-1] = systemctl_list[c-1] + "       进程已启动！"
            else:
                print("输入错误或进程已启动!")
        except:
            pass
    news = systemctl_list
    if cho != "Q":
        time.sleep(1)
        user_choise(news)





if __name__ == '__main__':
    #功能清单
    systemctl_list = [
            '[1]系统安全配置排查',
            '[2]账户安全排查',
            '[3]高权限用户排查',
            '[4]文件安全配置项目排查',
            '[5]mysql日志爆破监测',
            '[6]secure日志登录爆破检监测',
            '[7]CPU系统进程使用率监测',
            '[8]文件上传和写入关键配置文件监测',
            '[9]NIDS入侵流量监测',
            '[Q]退出系统'
            ]
    #进入交互模式
    user_choise(systemctl_list)
    print("退出程序。")


        
# return_path(user_safe.py)

# system_safe() #———————————系统安全配置排查（使用时启动）——————————————system_file_safe.py

# shadow_weak_pass()  #————————————账户安全排查（使用时启动）——————————————user_safe.py

# group_chack()  #————————————高权限用户检测（使用时启动）——————————————user_safe.py

# MySQL_log_blast()   #————————————mysql日志爆破检测   #log_file.py

# SSH_log_blast()    #————————————/var/log/secure 登录日志检测   #log_file.py

# cpu_chack()     #————————————mpstat + top    系统进程使用率监测     #计划任务  对进程进行检查检查cpu使用率较高的程序   * * * * *

# user_input()  #————————————文件安全配置项目（配置  脚本后台挂载  实时检测）——————————————peizhi_safe.py  #  cd HIDS/ && python3 ontime_chack.py

# ontime_file()  #————————————文件上传和写入关键配置文件检测(配置计  划任务启动/3S进行一次检测  )——————————————ontime_chack.py

#

