from log_files import *
import time,os
while True:
    time.sleep(3)
    MySQL_log_blast()
    SSH_log_blast()
    cpu_chack()
