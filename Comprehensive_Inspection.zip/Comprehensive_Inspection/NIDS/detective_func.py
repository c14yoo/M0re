import time,os


def test():
    print(123)

#计时器        
def time_limited(IP_src):
    for i in range(5, 0, -1):
        print(f'\r倒计时{i}秒,', end='')  # \r让光标回到行首 ，end=''--结束符为空，即不换行
        time.sleep(1)  # 让程序等待1秒
        with open('access_count.txt', 'r') as fp:
            num = fp.read()
            count_add2(num,IP_src)
    else:
        print('\r倒计时结束')



#在开始时间内进行计算次数的操作
def count_add2(num,IP_src):
    print("阶段访问次数：",num)
    if num >= '4':
        print("触发暴破预警,可疑IP地址为:",IP_src)
        make_choice(IP_src)



#间歇性清空文档，一分钟清一次。用Linux的crontab更好实现。crontab -e :* * * * * echo "0" > /opt/lampp/htdocs/NIDS/access_count.txt
# def delete_file():
#     while True:
#         time.sleep(30)
#         with open("access_count.txt", "w") as fp:
#           fp.write("0")
 
#打印出报告信息
def display(time_now,IP_src,threat_level,http_data2,payload,IP_dst):
    print('\r')
    print("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓")
    print("time: " + time_now)
    print("Source IP: " + IP_src)
    print("Destination IP: " + IP_dst)
    print("threat_level: " + threat_level)
    print("payload: " + payload)
    print("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑")
    print('\r') 
    print(http_data2)
    print('\r')
    return time_now, IP_src, payload, threat_level,IP_dst


#封禁IP,采用插入队首的方式。
def IP_block(IP_src):
    # os.system(f"iptables -I INPUT -s {IP_src} -j DROP")
    os.system(f"iptables -I INPUT -s {IP_src} -j DROP")
    print(f'现在，{IP_src}已被封禁。')

#封禁选择
def make_choice(IP_src):
    print("****press 1 to block IP****")
    print("****press 2 to ignore  ****")
    choice = input("press:")
    if choice == '1':
        IP_block(IP_src)
    else :
        pass


#Shell工具检查
def get_shell_ant(time_now,IP_src,threat_level,http_data2,payload,IP_dst):
    payload = "AntSword(shell_tool) flow detected"
    threat_level = "1"
    print("[+] !!!!!!Your System Has Been Get-shell!!!!!!:")
    display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
    make_choice(IP_src) 
    
def get_shell_behinder(time_now,IP_src,threat_level,http_data2,payload,IP_dst):
    payload = "Behinder(shell_tool) flow detected"
    threat_level = "1"
    print("[+] !!!!!!Your System Has Been Get-shell!!!!!!:")
    display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
    make_choice(IP_src) 

def get_shell_Godzila(time_now,IP_src,threat_level,http_data2,payload,IP_dst):
    payload = "Godzila(shell_tool) flow detected"
    threat_level = "1"
    print("[+] !!!!!!Your System Has Been Get-shell!!!!!!:")
    display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
    make_choice(IP_src) 
    
def get_shell_chopper(time_now,IP_src,threat_level,http_data2,payload,IP_dst):
    payload = "ChineseCaiDao(shell_tool) flow detected"
    threat_level = "1"
    print("[+] !!!!!!Your System Has Been Get-shell!!!!!!:")
    display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
    make_choice(IP_src) 