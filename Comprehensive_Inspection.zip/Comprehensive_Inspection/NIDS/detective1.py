# @脚本说明 :

# 该脚本会监听网络流量，当检测到TCP数据包中包含HTTP请求数据，并且该数据包的目的端口为80时，会检查HTTP请求数据是否包含SQL注入语句。如果检测到SQL注入，则打印相关信息。
# 该脚本使用正则表达式进行SQL注入语句的匹配，可以根据需要进行修改和优化。同时，该脚本只是一个简单的示例，实际使用中还需要考虑其他方面的安全问题。
# 联系TEST3 文档内容进行开发。
from detective_func import *
from scapy.all import *
import re, datetime,time
import urllib.parse
import sendmsg

def check_network_injection(packet):
    time_now = str(datetime.datetime.now())
    threat_level = ""
    IP_src = ""
    payload = ""

    # 检查是否为HTTP请求
    '''
    Scapy库中的haslayer方法是用来判断数据包是否包含指定的协议层的。
    它的用法是在Scapy的数据包对象上,调用haslayer方法,并传入想要判断的协议层的类型，
    如果该数据包包含这一层,那么返回True,否则返回False。
    packet[IP].src=='171.223.193.62'为测试需要，控制了数据来源。真实场景应对删除。
    '''
    if packet.haslayer(TCP) and packet.haslayer(Raw) and packet[TCP].dport == 80 :
        # 获取HTTP请求数据
        http_data = str(packet[Raw].load)
        # print(http_data)
        http_data1 = urllib.parse.unquote(http_data)  # 防止URL编码绕过
        http_data2 = http_data1.lower()  # 防止大小写绕过
        IP_src = packet[IP].src  #提取IP
        IP_dst = packet[IP].dst


        # 检查是否为SQL注入等基于字段检测就能发现的攻击
        result=re.search(r"union.+select|updatexml|concat|information_schema|and.+select|or.+select|&&.+select|\|\|.+select|and.+if|or.+if|&&.+if|\|\|.+if", http_data2)
        if result:
            match = re.search(r"match=(.*)>", str(result))
            payload = match.group(1)
            threat_level = '2'
            print("[+] !!!!!!Possible SQL intrution detected!!!!!!:")
            time_now, IP_src, payload, threat_level,IP_dst=display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            # print(f'测试：传递值成功,时间:{time_now},源IP:{IP_src},目的IP:{IP_dst},payload:{payload},threat_levet:{threat_level}')
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
            sendmsg.send(msg)
            # make_choice(IP_src)
            
        # 检查是否为xss注入等基于字段检测就能发现的攻击
        result_xss = re.search(r"%3Cscript%3E|javascript.*:|<script>|onclick.*=|onerror.*=|Image\(\)\.src|location\.href.*=", http_data2)
        if result_xss:
            print(result_xss)
            match = re.search(r"match=(.*)>", str(result_xss))
            payload = match.group(1)
            threat_level = '2'
            print("[+] !!!!!!Possible XSS intrution detected!!!!!!:")
            display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\nthreat_levet:{threat_level}\n若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
            sendmsg.send(msg)
            # make_choice(IP_src)
            

        # 检查是否被恶意扫描.PS:!doctype.+!entity检查XXE实体注入，../检查目录穿越.
        result_scanner = re.search(r"gopher.*|phar.*|dict.*|\.\./\.\./.+|!doctype.+!entity", http_data2)
        if result_scanner: 
            # print(result)
            match = re.search(r"match=(.*)>", str(result_scanner))
            payload = match.group(1)
            threat_level = '3'
            print("[+] !!!!!!suspected to be maliciously scanned!!!!!!:")
            display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
            sendmsg.send(msg)
            # make_choice(IP_src)
            

        # 检查是否为反序列化攻击   
        if re.search(r".*%22S%22%3A1.*|.*%3A%7Bs%3A1.*|.*\"S\":.*|.*:\{s.*|content-length:.+(o:.*\";\})'", http_data2):
            # result = re.search(r".*%22S%22%3A1.*|.*%3A%7Bs%3A1.*|.*\"S\":.*|.*:\{s.*|content-length:.+(o:.*\";\})'", http_data2)
            # print(result)
            match = re.search(r"content-length:.+(o:.*\";\})'", http_data2)   
            # match = re.search(r"match='(.*)'", str(result))
            payload = match.group(1)
            threat_level = '2'
            print("[+] !!!!!!Possible unserialize intrution detected!!!!!!:")
            display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
            sendmsg.send(msg)
            # make_choice(IP_src)


        # 检查是否为CSRF等需要进行校验才能发现的攻击,目前该规则在正常访问时容易报错。
        match = re.search(r"Referer: http://(\d+\.\d+\.\d+\.\d+)/", http_data)
        if match:
            # match2 = re.search(r"Referer: http://(\d+\.\d+\.\d+\.\d+/\S+)\\r\\nCookie", http_data)
            threat_level = '2'
            local_ip = match.group(1)
            payload = "CSRF link chain"
            if local_ip != '114.132.214.155':
                print('[+] !!!!!!A CSRF link has been clicked already!!!!!!:')
                display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
                sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
                msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
                sendmsg.send(msg)
                # make_choice(IP_src)
                

        # 检查上传文件的内容是否存在危险：
        if 'multipart/form-data' in http_data:
            match = re.search(r"filename=\"(.+\.\S+)\"", http_data)
            filename = match.group(1)
            if re.search(r"eval\(", http_data2):
                threat_level = "1"
                payload = filename
                print('[+] !!!!!!The uploaded file was considered to a invasion !!!!!!:')
                display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
                sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
                msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
                sendmsg.send(msg)
                # make_choice(IP_src)
                

        #检测爆破攻击  username=.*password=.*
        if re.search(r"username=.*password=.*",http_data2):
            payload = "burst"
            threat_level="3"
            with open('access_count.txt', 'r') as fp:
                num = fp.read()
                num = int(num)
                num += 1
            with open('access_count.txt', 'w') as fp:            
                fp.write(str(num))            
            time_limited(IP_src)
            display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            
        
        #蚁剑检测
        if re.search(r".*QGluaV9zZXQoImRpc3BsYXlfZXJyb3JzIiwgIjAiKTtAc.*|.+qvfcynl_reebef.+|.+function%20asenc.+|ChR\(116\).ChR\(41\).ChR\(123\).|ChR\(0x20\).ChR\(0x61\).ChR\(0x73\)|\$bpjq=qveanzr",http_data):
            get_shell_ant(time_now,IP_src,threat_level,http_data2,payload,IP_dst) 
        #冰蝎检测
        if re.search(r"3Mn1yNMtoZViV5wotQHPJtwwj0F4b2l",http_data):
            get_shell_behinder(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
        #哥斯拉检测
        if re.search(r".*urldecode%28%27K0QfK0QfgACIgoQD9BCIgACIgACIK0wOpkXZrRCLhRXYk.*",http_data):
            get_shell_Godzila(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
        #菜刀检测：
        if re.search(r".*gwKTtAc2V0X21hZ2ljX3F1b3Rlc19ydW50aW1lKDApO2V.*",http_data):
            get_shell_chopper(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            
            
        # 检查是否存在基于Linux系统的命令注入
        result_cmd = re.search(r"wget.*|crontab.*|echo.*>.*|echo.*>>.*|netstat.*", http_data2)
        if result_cmd:
            print(result_cmd)
            match = re.search(r"match=(.*)>", str(result_cmd))
            payload = match.group(1)
            threat_level = '2'
            print("[+] !!!!!!Possible command intrution detected!!!!!!:")
            display(time_now,IP_src,threat_level,http_data2,payload,IP_dst)
            sendmsg.WebINnfo(IP_src,payload,time_now,threat_level)
            msg=(f"""检测到攻击行为\n时间:{time_now}\n源IP:{IP_src}\npayload:{payload}\n threat_levet:{threat_level}\n 若需处理请查看:http://114.132.214.155/web/nids/detail.html""")
            sendmsg.send(msg)
            # make_choice(IP_src)
        


def main():
    sniff(filter="tcp and port 80", prn=check_network_injection)


if __name__ == '__main__':
    main()









